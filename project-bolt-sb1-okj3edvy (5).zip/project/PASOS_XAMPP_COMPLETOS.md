# 🚀 Configuración Completa XAMPP - Paso a Paso

## 📋 **PASO 1: Generar el Build de Producción**

1. **En la terminal del proyecto:**
   ```bash
   npm run build
   ```

2. **Verificar que se creó la carpeta `dist/`** con estos archivos:
   ```
   dist/
   ├── index.html
   ├── .htaccess
   └── assets/
       ├── index-[hash].js
       ├── index-[hash].css
       └── [otros archivos]
   ```

## 📂 **PASO 2: Copiar Archivos a XAMPP**

1. **Ir a la carpeta de XAMPP:**
   ```
   C:\xampp\htdocs\
   ```

2. **Crear carpeta del proyecto:**
   ```
   C:\xampp\htdocs\tactical-ops\
   ```

3. **Copiar TODO el contenido de `dist/` a la carpeta de XAMPP:**
   ```
   Copiar desde: [tu-proyecto]/dist/*
   Pegar en: C:\xampp\htdocs\tactical-ops\
   ```

4. **Agregar los archivos de la base de datos:**
   ```
   C:\xampp\htdocs\tactical-ops\
   ├── index.html (copiado de dist)
   ├── .htaccess (copiado de dist)
   ├── assets/ (copiado de dist)
   ├── database/
   │   └── connection.php
   ├── api/
   │   ├── auth.php
   │   ├── users.php
   │   ├── news.php
   │   ├── comments.php
   │   ├── messages.php
   │   └── clans.php
   └── test_connection.php
   ```

## ⚙️ **PASO 3: Configurar Apache (httpd.conf)**

1. **Abrir archivo:**
   ```
   C:\xampp\apache\conf\httpd.conf
   ```

2. **Buscar y descomentar (quitar #):**
   ```apache
   LoadModule rewrite_module modules/mod_rewrite.so
   LoadModule headers_module modules/mod_headers.so
   LoadModule expires_module modules/mod_expires.so
   LoadModule deflate_module modules/mod_deflate.so
   ```

3. **Buscar `<IfModule mod_mime_module>` y agregar:**
   ```apache
   <IfModule mod_mime_module>
       # Configuración existente...
       
       # AGREGAR ESTAS LÍNEAS:
       AddType application/javascript .js
       AddType application/javascript .mjs
       AddType text/css .css
       AddType text/html .html
   </IfModule>
   ```

## 🔄 **PASO 4: Reiniciar Apache**

1. **En el Panel de Control de XAMPP:**
   - Stop Apache
   - Esperar 5 segundos
   - Start Apache

## 🗄️ **PASO 5: Configurar Base de Datos**

1. **Abrir Navicat**
2. **Crear conexión MySQL:**
   - Host: localhost
   - Puerto: 3306
   - Usuario: root
   - Contraseña: (vacío)

3. **Ejecutar el archivo SQL:**
   - Clic derecho → "Execute SQL File"
   - Seleccionar: `supabase/migrations/20250612003549_humble_unit.sql`
   - Ejecutar

## ✅ **PASO 6: Verificar que Todo Funciona**

1. **Probar conexión a base de datos:**
   ```
   http://localhost/tactical-ops/test_connection.php
   ```

2. **Abrir la aplicación:**
   ```
   http://localhost/tactical-ops/
   ```

3. **Hacer login con:**
   - Usuario: `root`
   - Contraseña: `tacticalopschile2025`

## 🔧 **PASO 7: Si Sigue en Blanco**

### **Verificar en DevTools (F12):**

1. **Consola (Console):** Buscar errores en rojo
2. **Network:** Verificar que los archivos .js tengan:
   - Status: 200 OK
   - Content-Type: application/javascript

### **Limpiar Cache:**
- `Ctrl + Shift + R` (recarga forzada)
- O en DevTools: Network → "Disable cache"

### **Verificar Estructura Final:**
```
C:\xampp\htdocs\tactical-ops\
├── index.html ✅
├── .htaccess ✅
├── assets/
│   ├── index-[hash].js ✅
│   ├── index-[hash].css ✅
│   └── [otros archivos] ✅
├── database/
│   └── connection.php ✅
├── api/
│   ├── auth.php ✅
│   ├── users.php ✅
│   ├── news.php ✅
│   ├── comments.php ✅
│   ├── messages.php ✅
│   └── clans.php ✅
└── test_connection.php ✅
```

## 🚨 **Solución de Emergencia**

Si XAMPP sigue dando problemas, usa servidor alternativo:

```bash
# En la carpeta del proyecto
cd C:\xampp\htdocs\tactical-ops
python -m http.server 8000

# Luego abre: http://localhost:8000
```

## 🎯 **Resultado Final**

✅ Página carga completamente
✅ Sin errores en consola
✅ Base de datos funcionando
✅ Login funcional
✅ Datos se guardan permanentemente

## 📞 **Si Necesitas Ayuda**

1. **Revisa logs de Apache:**
   ```
   C:\xampp\apache\logs\error.log
   ```

2. **Verifica que MySQL esté corriendo** en el panel de XAMPP

3. **Asegúrate de que el puerto 80 esté libre**