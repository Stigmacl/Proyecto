import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Message {
  id: string;
  fromUserId: string;
  toUserId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

interface Comment {
  id: string;
  author: string;
  content: string;
  date: string;
  avatar: string;
  isDeleted?: boolean;
  deletedBy?: string;
  deletedAt?: string;
  deletionReason?: string;
}

interface NewsItem {
  id: string;
  title: string;
  content: string;
  image: string;
  author: string;
  date: string;
  isPinned: boolean;
  views: number;
  comments: Comment[];
  likes: number;
  likedBy: string[]; // Array of user IDs who liked this news
}

interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'player';
  avatar?: string;
  status?: string;
  isOnline: boolean;
  clan?: string;
  isActive: boolean;
  lastLogin?: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (username: string, email: string, password: string) => Promise<boolean>;
  users: User[];
  updateUser: (userId: string, updates: Partial<User>) => void;
  changeUserPassword: (userId: string, newPassword: string) => boolean;
  toggleUserStatus: (userId: string) => void;
  deleteUser: (userId: string) => boolean;
  messages: Message[];
  sendMessage: (toUserId: string, content: string) => void;
  markMessageAsRead: (messageId: string) => void;
  getConversation: (userId1: string, userId2: string) => Message[];
  getUnreadCount: (userId: string) => number;
  news: NewsItem[];
  createNews: (newsData: Omit<NewsItem, 'id' | 'views' | 'comments' | 'likes' | 'likedBy'>) => void;
  updateNews: (newsId: string, updates: Partial<NewsItem>) => void;
  deleteNews: (newsId: string) => void;
  likeNews: (newsId: string) => void;
  addComment: (newsId: string, content: string) => void;
  incrementNewsViews: (newsId: string) => void;
  deleteComment: (newsId: string, commentId: string, reason?: string) => void;
  restoreComment: (newsId: string, commentId: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// Simple password storage for demo purposes (in production, use proper hashing)
const userPasswords: { [userId: string]: string } = {
  '1': 'tacticalopschile2025'
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);

  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      username: 'root',
      email: 'admin@tacops.cl',
      role: 'admin',
      avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      status: 'Administrador del sistema',
      isOnline: true,
      isActive: true,
      clan: 'ADMIN',
      lastLogin: new Date().toISOString(),
      createdAt: '2025-01-01T00:00:00.000Z'
    }
  ]);

  // Initialize passwords for demo users
  React.useEffect(() => {
    users.forEach(user => {
      if (!userPasswords[user.id] && user.id !== '1') {
        userPasswords[user.id] = 'demo123';
      }
    });
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    const foundUser = users.find(u => u.username === username);
    
    if (!foundUser) return false;
    
    // Check if user is active
    if (!foundUser.isActive) return false;
    
    // Check password
    if (userPasswords[foundUser.id] === password) {
      const updatedUser = {
        ...foundUser,
        isOnline: true,
        lastLogin: new Date().toISOString()
      };
      
      setUser(updatedUser);
      setUsers(prev => prev.map(u => u.id === foundUser.id ? updatedUser : u));
      return true;
    }
    
    return false;
  };

  const register = async (username: string, email: string, password: string): Promise<boolean> => {
    // Check if username or email already exists
    const existingUser = users.find(u => u.username === username || u.email === email);
    if (existingUser) {
      return false;
    }

    const newUserId = Date.now().toString();
    const newUser: User = {
      id: newUserId,
      username,
      email,
      role: 'player',
      avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      status: 'Nuevo jugador',
      isOnline: true,
      isActive: true,
      lastLogin: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    // Store password
    userPasswords[newUserId] = password;

    setUsers(prev => [...prev, newUser]);
    setUser(newUser);
    return true;
  };

  const logout = () => {
    if (user) {
      setUsers(prev => prev.map(u => 
        u.id === user.id ? { ...u, isOnline: false } : u
      ));
    }
    setUser(null);
  };

  const updateUser = (userId: string, updates: Partial<User>) => {
    if (user && user.id === userId) {
      setUser({ ...user, ...updates });
    }
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
  };

  const changeUserPassword = (userId: string, newPassword: string): boolean => {
    try {
      userPasswords[userId] = newPassword;
      return true;
    } catch {
      return false;
    }
  };

  const toggleUserStatus = (userId: string) => {
    setUsers(prev => prev.map(u => 
      u.id === userId ? { ...u, isActive: !u.isActive, isOnline: u.isActive ? false : u.isOnline } : u
    ));
    
    // If current user is being deactivated, log them out
    if (user && user.id === userId) {
      const updatedUser = users.find(u => u.id === userId);
      if (updatedUser && !updatedUser.isActive) {
        setUser(null);
      }
    }
  };

  const deleteUser = (userId: string): boolean => {
    // Prevent deleting the root admin
    if (userId === '1') return false;
    
    setUsers(prev => prev.filter(u => u.id !== userId));
    delete userPasswords[userId];
    
    // If current user is being deleted, log them out
    if (user && user.id === userId) {
      setUser(null);
    }
    
    return true;
  };

  const sendMessage = (toUserId: string, content: string) => {
    if (!user) return;
    
    const newMessage: Message = {
      id: Date.now().toString(),
      fromUserId: user.id,
      toUserId,
      content,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    
    setMessages(prev => [...prev, newMessage]);
  };

  const markMessageAsRead = (messageId: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, isRead: true } : msg
    ));
  };

  const getConversation = (userId1: string, userId2: string): Message[] => {
    return messages
      .filter(msg => 
        (msg.fromUserId === userId1 && msg.toUserId === userId2) ||
        (msg.fromUserId === userId2 && msg.toUserId === userId1)
      )
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  };

  const getUnreadCount = (userId: string): number => {
    return messages.filter(msg => 
      msg.toUserId === userId && !msg.isRead
    ).length;
  };

  const createNews = (newsData: Omit<NewsItem, 'id' | 'views' | 'comments' | 'likes' | 'likedBy'>) => {
    const newNews: NewsItem = {
      ...newsData,
      id: Date.now().toString(),
      views: 0,
      comments: [],
      likes: 0,
      likedBy: []
    };
    
    setNews(prev => [...prev, newNews]);
  };

  const updateNews = (newsId: string, updates: Partial<NewsItem>) => {
    setNews(prev => prev.map(item => 
      item.id === newsId ? { ...item, ...updates } : item
    ));
  };

  const deleteNews = (newsId: string) => {
    setNews(prev => prev.filter(item => item.id !== newsId));
  };

  const likeNews = (newsId: string) => {
    if (!user) return;
    
    setNews(prev => prev.map(item => {
      if (item.id === newsId) {
        const hasLiked = item.likedBy.includes(user.id);
        
        if (hasLiked) {
          // Unlike
          return {
            ...item,
            likes: item.likes - 1,
            likedBy: item.likedBy.filter(id => id !== user.id)
          };
        } else {
          // Like
          return {
            ...item,
            likes: item.likes + 1,
            likedBy: [...item.likedBy, user.id]
          };
        }
      }
      return item;
    }));
  };

  const addComment = (newsId: string, content: string) => {
    if (!user || !content.trim()) return;
    
    const newComment: Comment = {
      id: Date.now().toString(),
      author: user.username,
      content: content.trim(),
      date: new Date().toISOString(),
      avatar: user.avatar || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop'
    };
    
    setNews(prev => prev.map(item => 
      item.id === newsId 
        ? { ...item, comments: [...item.comments, newComment] }
        : item
    ));
  };

  const incrementNewsViews = (newsId: string) => {
    setNews(prev => prev.map(item => 
      item.id === newsId 
        ? { ...item, views: item.views + 1 }
        : item
    ));
  };

  const deleteComment = (newsId: string, commentId: string, reason?: string) => {
    if (!user || user.role !== 'admin') return;
    
    setNews(prev => prev.map(item => {
      if (item.id === newsId) {
        return {
          ...item,
          comments: item.comments.map(comment => 
            comment.id === commentId 
              ? {
                  ...comment,
                  isDeleted: true,
                  deletedBy: user.username,
                  deletedAt: new Date().toISOString(),
                  deletionReason: reason || 'Contenido inapropiado'
                }
              : comment
          )
        };
      }
      return item;
    }));
  };

  const restoreComment = (newsId: string, commentId: string) => {
    if (!user || user.role !== 'admin') return;
    
    setNews(prev => prev.map(item => {
      if (item.id === newsId) {
        return {
          ...item,
          comments: item.comments.map(comment => 
            comment.id === commentId 
              ? {
                  ...comment,
                  isDeleted: false,
                  deletedBy: undefined,
                  deletedAt: undefined,
                  deletionReason: undefined
                }
              : comment
          )
        };
      }
      return item;
    }));
  };

  return (
    <AuthContext.Provider value={{
      user,
      isLoggedIn: !!user,
      login,
      logout,
      register,
      users,
      updateUser,
      changeUserPassword,
      toggleUserStatus,
      deleteUser,
      messages,
      sendMessage,
      markMessageAsRead,
      getConversation,
      getUnreadCount,
      news,
      createNews,
      updateNews,
      deleteNews,
      likeNews,
      addComment,
      incrementNewsViews,
      deleteComment,
      restoreComment
    }}>
      {children}
    </AuthContext.Provider>
  );
};