import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize2 } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface VideoBannerProps {
  videoSrc?: string;
  gifSrc?: string;
  posterSrc?: string;
  title?: string;
  subtitle?: string;
  height?: string;
  showControls?: boolean;
  autoplay?: boolean;
  muted?: boolean;
}

const VideoBanner: React.FC<VideoBannerProps> = ({
  videoSrc = 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
  gifSrc,
  posterSrc = 'https://images.pexels.com/photos/163444/war-soldiers-warrior-battle-163444.jpeg?auto=compress&cs=tinysrgb&w=1920&h=400&fit=crop',
  title = 'Tactical Ops 3.5 Chile',
  subtitle = 'La comunidad más activa de Tactical Operations',
  height = 'h-64 md:h-80 lg:h-96',
  showControls = true,
  autoplay = true,
  muted = true
}) => {
  const { themeConfig } = useTheme();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(autoplay);
  const [isMuted, setIsMuted] = useState(muted);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedData = () => {
      setIsLoaded(true);
      if (autoplay) {
        video.play().catch(console.error);
      }
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    video.addEventListener('loadeddata', handleLoadedData);
    video.addEventListener('play', handlePlay);
    video.addEventListener('pause', handlePause);

    return () => {
      video.removeEventListener('loadeddata', handleLoadedData);
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('pause', handlePause);
    };
  }, [autoplay]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      video.play().catch(console.error);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const toggleFullscreen = () => {
    const video = videoRef.current;
    if (!video) return;

    if (!document.fullscreenElement) {
      video.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(console.error);
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      }).catch(console.error);
    };
  };

  const handleVideoClick = () => {
    setShowOverlay(false);
    setTimeout(() => setShowOverlay(true), 3000);
  };

  return (
    <div className={`relative w-full ${height} overflow-hidden`}>
      {/* Video/GIF Background */}
      <div className="absolute inset-0">
        {gifSrc ? (
          <img
            src={gifSrc}
            alt="Banner GIF"
            className="w-full h-full object-cover"
          />
        ) : (
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            poster={posterSrc}
            loop
            muted={isMuted}
            playsInline
            preload="metadata"
            onClick={handleVideoClick}
          >
            <source src={videoSrc} type="video/mp4" />
            Tu navegador no soporta el elemento de video.
          </video>
        )}
      </div>

      {/* Dark Military Gradient Overlay */}
      <div 
        className="absolute inset-0"
        style={{
          background: `linear-gradient(135deg, rgba(0,0,0,0.7), transparent 50%, rgba(0,0,0,0.5))`
        }}
      ></div>

      {/* Military Themed Overlay */}
      <div 
        className="absolute inset-0"
        style={{
          background: `linear-gradient(45deg, ${themeConfig.colors.primary}20, transparent 70%, ${themeConfig.colors.secondary}15)`
        }}
      ></div>

      {/* Animated Particles Effect - War Theme */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.1%22%3E%3Ccircle%20cx%3D%227%22%20cy%3D%227%22%20r%3D%221%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E')] animate-pulse"></div>
      </div>

      {/* Content Overlay - Centered Text Only */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center px-6 max-w-4xl mx-auto">
          <h1 
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 drop-shadow-2xl"
            style={{ 
              color: themeConfig.colors.text,
              textShadow: `0 0 30px ${themeConfig.colors.primary}80, 0 4px 8px rgba(0,0,0,0.9), 0 0 60px rgba(255,255,255,0.3)`
            }}
          >
            {title}
          </h1>
          <p 
            className="text-lg md:text-xl lg:text-2xl font-medium drop-shadow-lg"
            style={{ 
              color: themeConfig.colors.textSecondary,
              textShadow: '0 2px 4px rgba(0,0,0,0.9), 0 0 20px rgba(255,255,255,0.2)'
            }}
          >
            {subtitle}
          </p>
          
          {/* Military-style decorative elements */}
          <div className="mt-6 flex justify-center space-x-4">
            <div 
              className="w-16 h-0.5 opacity-60"
              style={{ backgroundColor: themeConfig.colors.primary }}
            ></div>
            <div 
              className="w-2 h-2 rounded-full opacity-80"
              style={{ backgroundColor: themeConfig.colors.accent }}
            ></div>
            <div 
              className="w-16 h-0.5 opacity-60"
              style={{ backgroundColor: themeConfig.colors.primary }}
            ></div>
          </div>
        </div>
      </div>

      {/* Video Controls */}
      {!gifSrc && showControls && showOverlay && isLoaded && (
        <div className="absolute bottom-4 right-4 flex space-x-2">
          <button
            onClick={togglePlay}
            className="p-3 rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-110 border"
            style={{
              backgroundColor: `rgba(0,0,0,0.7)`,
              borderColor: `${themeConfig.colors.primary}60`,
              color: themeConfig.colors.primary
            }}
            title={isPlaying ? 'Pausar' : 'Reproducir'}
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </button>
          
          <button
            onClick={toggleMute}
            className="p-3 rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-110 border"
            style={{
              backgroundColor: `rgba(0,0,0,0.7)`,
              borderColor: `${themeConfig.colors.primary}60`,
              color: themeConfig.colors.primary
            }}
            title={isMuted ? 'Activar sonido' : 'Silenciar'}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
          
          <button
            onClick={toggleFullscreen}
            className="p-3 rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-110 border"
            style={{
              backgroundColor: `rgba(0,0,0,0.7)`,
              borderColor: `${themeConfig.colors.primary}60`,
              color: themeConfig.colors.primary
            }}
            title="Pantalla completa"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Loading Indicator */}
      {!isLoaded && !gifSrc && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div 
            className="w-16 h-16 border-4 border-t-transparent rounded-full animate-spin"
            style={{ borderColor: `${themeConfig.colors.primary} transparent transparent transparent` }}
          ></div>
        </div>
      )}

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div 
          className="w-6 h-10 border-2 rounded-full flex justify-center"
          style={{ borderColor: `${themeConfig.colors.textSecondary}60` }}
        >
          <div 
            className="w-1 h-3 rounded-full mt-2 animate-pulse"
            style={{ backgroundColor: themeConfig.colors.textSecondary }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default VideoBanner;