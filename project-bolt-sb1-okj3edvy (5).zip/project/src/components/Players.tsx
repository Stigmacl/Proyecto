import React, { useState } from 'react';
import { Users, Search, Filter, UserCheck, UserX, Clock, MapPin, Shield, Star, MessageCircle, X, Send } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Players: React.FC = () => {
  const { users, user, sendMessage } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'online' | 'offline'>('all');
  const [roleFilter, setRoleFilter] = useState<'all' | 'admin' | 'player'>('all');
  const [clanFilter, setClanFilter] = useState<string>('all');
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [messageContent, setMessageContent] = useState('');

  // Get unique clans from users
  const getUniqueClans = () => {
    const clans = users
      .map(user => user.clan)
      .filter(clan => clan && clan.trim() !== '')
      .filter((clan, index, array) => array.indexOf(clan) === index)
      .sort();
    return clans;
  };

  const uniqueClans = getUniqueClans();

  const filteredUsers = users.filter(userItem => {
    const matchesSearch = userItem.username.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'online' && userItem.isOnline) || 
      (statusFilter === 'offline' && !userItem.isOnline);
    const matchesRole = roleFilter === 'all' || userItem.role === roleFilter;
    const matchesClan = clanFilter === 'all' || 
      (clanFilter === 'no-clan' && (!userItem.clan || userItem.clan.trim() === '')) ||
      userItem.clan === clanFilter;
    
    return matchesSearch && matchesStatus && matchesRole && matchesClan;
  });

  const getStatusColor = (isOnline: boolean) => {
    return isOnline 
      ? 'bg-green-500 shadow-lg shadow-green-500/30' 
      : 'bg-gray-500';
  };

  const getStatusText = (isOnline: boolean) => {
    return isOnline ? 'En línea' : 'Desconectado';
  };

  const getRoleIcon = (role: string) => {
    return role === 'admin' ? (
      <Shield className="w-4 h-4 text-yellow-400" />
    ) : (
      <Star className="w-4 h-4 text-blue-400" />
    );
  };

  const getRoleBadgeColor = (role: string) => {
    return role === 'admin' 
      ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' 
      : 'bg-blue-500/20 text-blue-300 border-blue-500/30';
  };

  const handleSendMessage = (targetUser: any) => {
    if (!user) {
      alert('Debes iniciar sesión para enviar mensajes');
      return;
    }
    
    if (targetUser.id === user.id) {
      alert('No puedes enviarte un mensaje a ti mismo');
      return;
    }
    
    setSelectedUser(targetUser);
    setShowMessageModal(true);
  };

  const handleSubmitMessage = () => {
    if (!messageContent.trim() || !selectedUser || !user) return;
    
    sendMessage(selectedUser.id, messageContent);
    setMessageContent('');
    setShowMessageModal(false);
    setSelectedUser(null);
    alert('Mensaje enviado correctamente');
  };

  // Get statistics including clan stats
  const getStats = () => {
    const total = users.length;
    const online = users.filter(u => u.isOnline).length;
    const offline = users.filter(u => !u.isOnline).length;
    const admins = users.filter(u => u.role === 'admin').length;
    const withClan = users.filter(u => u.clan && u.clan.trim() !== '').length;
    const withoutClan = users.filter(u => !u.clan || u.clan.trim() === '').length;
    
    return { total, online, offline, admins, withClan, withoutClan };
  };

  const stats = getStats();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-4">Comunidad de Jugadores</h1>
        <p className="text-blue-200 text-lg">Conoce a los miembros de nuestra comunidad</p>
      </div>

      {/* Filters and Search */}
      <div className="mb-8 bg-slate-800/40 backdrop-blur-lg rounded-2xl border border-blue-700/30 p-6">
        <div className="flex flex-col gap-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-blue-400" />
            <input
              type="text"
              placeholder="Buscar jugadores..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-700/40 border border-blue-600/30 rounded-xl text-white placeholder-blue-300 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
          
          {/* Filter Row */}
          <div className="grid md:grid-cols-4 gap-3">
            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as 'all' | 'online' | 'offline')}
              className="px-4 py-3 bg-slate-700/40 border border-blue-600/30 rounded-xl text-white focus:outline-none focus:border-blue-500 transition-colors"
            >
              <option value="all">Todos los estados</option>
              <option value="online">En línea ({stats.online})</option>
              <option value="offline">Desconectados ({stats.offline})</option>
            </select>
            
            {/* Role Filter */}
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value as 'all' | 'admin' | 'player')}
              className="px-4 py-3 bg-slate-700/40 border border-blue-600/30 rounded-xl text-white focus:outline-none focus:border-blue-500 transition-colors"
            >
              <option value="all">Todos los roles</option>
              <option value="admin">Administradores ({stats.admins})</option>
              <option value="player">Jugadores ({stats.total - stats.admins})</option>
            </select>

            {/* Clan Filter */}
            <select
              value={clanFilter}
              onChange={(e) => setClanFilter(e.target.value)}
              className="px-4 py-3 bg-slate-700/40 border border-blue-600/30 rounded-xl text-white focus:outline-none focus:border-blue-500 transition-colors"
            >
              <option value="all">Todos los clanes</option>
              <option value="no-clan">Sin clan ({stats.withoutClan})</option>
              {uniqueClans.map(clan => {
                const clanCount = users.filter(u => u.clan === clan).length;
                return (
                  <option key={clan} value={clan}>
                    [{clan}] ({clanCount})
                  </option>
                );
              })}
            </select>

            {/* Clear Filters Button */}
            <button
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('all');
                setRoleFilter('all');
                setClanFilter('all');
              }}
              className="px-4 py-3 bg-red-600/20 hover:bg-red-600/30 border border-red-500/30 rounded-xl text-red-300 hover:text-red-200 transition-colors flex items-center justify-center space-x-2"
            >
              <X className="w-4 h-4" />
              <span>Limpiar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid md:grid-cols-6 gap-4 mb-8">
        <div className="bg-slate-800/40 backdrop-blur-lg rounded-xl border border-blue-700/30 p-4">
          <div className="flex items-center space-x-3">
            <Users className="w-6 h-6 text-blue-400" />
            <div>
              <p className="text-xl font-bold text-white">{stats.total}</p>
              <p className="text-blue-300 text-xs">Total</p>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800/40 backdrop-blur-lg rounded-xl border border-blue-700/30 p-4">
          <div className="flex items-center space-x-3">
            <UserCheck className="w-6 h-6 text-green-400" />
            <div>
              <p className="text-xl font-bold text-white">{stats.online}</p>
              <p className="text-green-300 text-xs">En Línea</p>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800/40 backdrop-blur-lg rounded-xl border border-blue-700/30 p-4">
          <div className="flex items-center space-x-3">
            <UserX className="w-6 h-6 text-gray-400" />
            <div>
              <p className="text-xl font-bold text-white">{stats.offline}</p>
              <p className="text-gray-300 text-xs">Offline</p>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800/40 backdrop-blur-lg rounded-xl border border-blue-700/30 p-4">
          <div className="flex items-center space-x-3">
            <Shield className="w-6 h-6 text-yellow-400" />
            <div>
              <p className="text-xl font-bold text-white">{stats.admins}</p>
              <p className="text-yellow-300 text-xs">Admins</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/40 backdrop-blur-lg rounded-xl border border-blue-700/30 p-4">
          <div className="flex items-center space-x-3">
            <Shield className="w-6 h-6 text-purple-400" />
            <div>
              <p className="text-xl font-bold text-white">{stats.withClan}</p>
              <p className="text-purple-300 text-xs">Con Clan</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/40 backdrop-blur-lg rounded-xl border border-blue-700/30 p-4">
          <div className="flex items-center space-x-3">
            <Users className="w-6 h-6 text-gray-400" />
            <div>
              <p className="text-xl font-bold text-white">{stats.withoutClan}</p>
              <p className="text-gray-300 text-xs">Sin Clan</p>
            </div>
          </div>
        </div>
      </div>

      {/* Active Filters Display */}
      {(searchTerm || statusFilter !== 'all' || roleFilter !== 'all' || clanFilter !== 'all') && (
        <div className="mb-6 bg-blue-600/10 border border-blue-500/30 rounded-xl p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Filter className="w-4 h-4 text-blue-400" />
            <span className="text-blue-300 font-medium">Filtros activos:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {searchTerm && (
              <span className="px-3 py-1 bg-blue-600/20 text-blue-300 rounded-full text-sm">
                Búsqueda: "{searchTerm}"
              </span>
            )}
            {statusFilter !== 'all' && (
              <span className="px-3 py-1 bg-green-600/20 text-green-300 rounded-full text-sm">
                Estado: {statusFilter === 'online' ? 'En línea' : 'Desconectados'}
              </span>
            )}
            {roleFilter !== 'all' && (
              <span className="px-3 py-1 bg-yellow-600/20 text-yellow-300 rounded-full text-sm">
                Rol: {roleFilter === 'admin' ? 'Administradores' : 'Jugadores'}
              </span>
            )}
            {clanFilter !== 'all' && (
              <span className="px-3 py-1 bg-purple-600/20 text-purple-300 rounded-full text-sm">
                Clan: {clanFilter === 'no-clan' ? 'Sin clan' : `[${clanFilter}]`}
              </span>
            )}
          </div>
          <p className="text-blue-400 text-sm mt-2">
            Mostrando {filteredUsers.length} de {users.length} jugadores
          </p>
        </div>
      )}

      {/* Players Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map((userItem) => (
          <div
            key={userItem.id}
            className="bg-slate-800/40 backdrop-blur-lg rounded-2xl border border-blue-700/30 p-6 shadow-2xl hover:shadow-blue-500/10 transition-all duration-300 hover:transform hover:scale-105"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <img
                    src={userItem.avatar || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop'}
                    alt={userItem.username}
                    className="w-16 h-16 rounded-full border-4 border-blue-500/30"
                  />
                  <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full ${getStatusColor(userItem.isOnline)} border-2 border-slate-800`}></div>
                </div>
                
                <div>
                  <h3 className="text-lg font-bold text-white">{userItem.username}</h3>
                  <p className="text-blue-300 text-sm">{userItem.email}</p>
                </div>
              </div>
              
              <div className={`px-3 py-1 rounded-full border text-xs font-medium flex items-center space-x-1 ${getRoleBadgeColor(userItem.role)}`}>
                {getRoleIcon(userItem.role)}
                <span>{userItem.role === 'admin' ? 'Admin' : 'Jugador'}</span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-blue-400">Estado:</span>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${getStatusColor(userItem.isOnline)}`}></div>
                  <span className="text-white">{getStatusText(userItem.isOnline)}</span>
                </div>
              </div>

              {userItem.status && (
                <div className="text-sm">
                  <span className="text-blue-400">Estado personalizado:</span>
                  <p className="text-white italic mt-1">"{userItem.status}"</p>
                </div>
              )}

              <div className="flex items-center justify-between text-sm">
                <span className="text-blue-400">Clan:</span>
                {userItem.clan ? (
                  <div className="px-2 py-1 bg-purple-600/20 rounded text-purple-300 font-mono text-xs">
                    [{userItem.clan}]
                  </div>
                ) : (
                  <span className="text-gray-400 italic">Sin clan</span>
                )}
              </div>

              <div className="pt-3 border-t border-blue-700/30">
                <div className="flex items-center space-x-4 text-xs text-blue-400">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>Recién conectado</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-3 h-3" />
                    <span>Chile</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-blue-700/30">
              <div className="flex justify-between items-center">
                <button className="text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors">
                  Ver Perfil
                </button>
                <button 
                  onClick={() => handleSendMessage(userItem)}
                  className="flex items-center space-x-1 px-3 py-1 bg-blue-600/20 hover:bg-blue-600/30 rounded-lg text-blue-300 hover:text-blue-200 text-sm font-medium transition-all duration-300"
                >
                  <MessageCircle className="w-3 h-3" />
                  <span>Enviar Mensaje</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-blue-400 mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-bold text-white mb-2">No se encontraron jugadores</h3>
          <p className="text-blue-300">Intenta ajustar los filtros de búsqueda</p>
          <button
            onClick={() => {
              setSearchTerm('');
              setStatusFilter('all');
              setRoleFilter('all');
              setClanFilter('all');
            }}
            className="mt-4 px-4 py-2 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 rounded-lg text-blue-300 hover:text-blue-200 transition-colors"
          >
            Limpiar todos los filtros
          </button>
        </div>
      )}

      {/* Message Modal */}
      {showMessageModal && selectedUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl border border-blue-700/30 p-6 max-w-md w-full">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <img
                  src={selectedUser.avatar || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop'}
                  alt={selectedUser.username}
                  className="w-10 h-10 rounded-full border-2 border-blue-500/30"
                />
                <div>
                  <h3 className="text-lg font-bold text-white">Enviar mensaje a {selectedUser.username}</h3>
                  <p className="text-blue-300 text-sm">{selectedUser.email}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowMessageModal(false);
                  setSelectedUser(null);
                  setMessageContent('');
                }}
                className="p-2 hover:bg-slate-700 rounded-lg text-blue-300 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-blue-300 text-sm font-medium mb-2">Mensaje</label>
                <textarea
                  value={messageContent}
                  onChange={(e) => setMessageContent(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-700/40 border border-blue-600/30 rounded-xl text-white placeholder-blue-300 focus:outline-none focus:border-blue-500 transition-colors resize-none"
                  placeholder="Escribe tu mensaje aquí..."
                />
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={handleSubmitMessage}
                  disabled={!messageContent.trim()}
                  className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 rounded-xl text-white font-medium transition-colors"
                >
                  <Send className="w-4 h-4" />
                  <span>Enviar Mensaje</span>
                </button>
                
                <button
                  onClick={() => {
                    setShowMessageModal(false);
                    setSelectedUser(null);
                    setMessageContent('');
                  }}
                  className="px-6 py-3 bg-slate-600 hover:bg-slate-700 rounded-xl text-white font-medium transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Players;