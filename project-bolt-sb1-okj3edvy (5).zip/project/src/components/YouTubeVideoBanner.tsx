import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize2, ExternalLink } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface YouTubeVideoBannerProps {
  youtubeUrl?: string;
  videoId?: string;
  posterSrc?: string;
  title?: string;
  subtitle?: string;
  height?: string;
  autoplay?: boolean;
  muted?: boolean;
  showYouTubeLink?: boolean;
}

const YouTubeVideoBanner: React.FC<YouTubeVideoBannerProps> = ({
  youtubeUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  videoId,
  posterSrc = 'https://images.pexels.com/photos/163444/war-soldiers-warrior-battle-163444.jpeg?auto=compress&cs=tinysrgb&w=1920&h=400&fit=crop',
  title = 'Tactical Ops 3.5 Chile',
  subtitle = 'La comunidad más activa de Tactical Operations',
  height = 'h-64 md:h-80 lg:h-96',
  autoplay = true,
  muted = true,
  showYouTubeLink = true
}) => {
  const { themeConfig } = useTheme();
  const [isLoaded, setIsLoaded] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true);
  const [useEmbedded, setUseEmbedded] = useState(false);

  // Extraer video ID de la URL de YouTube
  const extractVideoId = (url: string): string => {
    if (videoId) return videoId;
    
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : '';
  };

  const currentVideoId = extractVideoId(youtubeUrl);
  
  // URLs para diferentes usos
  const embedUrl = `https://www.youtube.com/embed/${currentVideoId}?autoplay=${autoplay ? 1 : 0}&mute=${muted ? 1 : 0}&loop=1&playlist=${currentVideoId}&controls=0&showinfo=0&rel=0&modestbranding=1`;
  const thumbnailUrl = `https://img.youtube.com/vi/${currentVideoId}/maxresdefault.jpg`;

  useEffect(() => {
    // Simular carga del video
    const timer = setTimeout(() => setIsLoaded(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const handlePlayClick = () => {
    setUseEmbedded(true);
    setShowOverlay(false);
  };

  const openYouTube = () => {
    window.open(youtubeUrl, '_blank');
  };

  return (
    <div className={`relative w-full ${height} overflow-hidden`}>
      {/* Background - YouTube Thumbnail or Embedded Video */}
      <div className="absolute inset-0">
        {useEmbedded ? (
          // Embedded YouTube Video
          <iframe
            className="w-full h-full object-cover"
            src={embedUrl}
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            onLoad={() => setIsLoaded(true)}
          />
        ) : (
          // YouTube Thumbnail as Background
          <div 
            className="w-full h-full bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url(${thumbnailUrl}), url(${posterSrc})`
            }}
          />
        )}
      </div>

      {/* Dark Military Gradient Overlay */}
      <div 
        className="absolute inset-0"
        style={{
          background: `linear-gradient(135deg, rgba(0,0,0,0.7), transparent 50%, rgba(0,0,0,0.5))`
        }}
      ></div>

      {/* Military Themed Overlay */}
      <div 
        className="absolute inset-0"
        style={{
          background: `linear-gradient(45deg, ${themeConfig.colors.primary}20, transparent 70%, ${themeConfig.colors.secondary}15)`
        }}
      ></div>

      {/* Content Overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center px-6 max-w-4xl mx-auto">
          <h1 
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 drop-shadow-2xl"
            style={{ 
              color: themeConfig.colors.text,
              textShadow: `0 0 30px ${themeConfig.colors.primary}80, 0 4px 8px rgba(0,0,0,0.9), 0 0 60px rgba(255,255,255,0.3)`
            }}
          >
            {title}
          </h1>
          <p 
            className="text-lg md:text-xl lg:text-2xl font-medium drop-shadow-lg"
            style={{ 
              color: themeConfig.colors.textSecondary,
              textShadow: '0 2px 4px rgba(0,0,0,0.9), 0 0 20px rgba(255,255,255,0.2)'
            }}
          >
            {subtitle}
          </p>
          
          {/* Military-style decorative elements */}
          <div className="mt-6 flex justify-center space-x-4">
            <div 
              className="w-16 h-0.5 opacity-60"
              style={{ backgroundColor: themeConfig.colors.primary }}
            ></div>
            <div 
              className="w-2 h-2 rounded-full opacity-80"
              style={{ backgroundColor: themeConfig.colors.accent }}
            ></div>
            <div 
              className="w-16 h-0.5 opacity-60"
              style={{ backgroundColor: themeConfig.colors.primary }}
            ></div>
          </div>
        </div>
      </div>

      {/* Play Button Overlay (when not embedded) */}
      {!useEmbedded && showOverlay && isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={handlePlayClick}
            className="group p-6 rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-110 border-2"
            style={{
              backgroundColor: `rgba(0,0,0,0.7)`,
              borderColor: `${themeConfig.colors.primary}80`,
              color: themeConfig.colors.primary
            }}
            title="Reproducir video de YouTube"
          >
            <Play className="w-12 h-12 group-hover:scale-110 transition-transform" />
          </button>
        </div>
      )}

      {/* YouTube Controls */}
      {showOverlay && isLoaded && (
        <div className="absolute bottom-4 right-4 flex space-x-2">
          {!useEmbedded && (
            <button
              onClick={handlePlayClick}
              className="p-3 rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-110 border"
              style={{
                backgroundColor: `rgba(0,0,0,0.7)`,
                borderColor: `${themeConfig.colors.primary}60`,
                color: themeConfig.colors.primary
              }}
              title="Reproducir video"
            >
              <Play className="w-5 h-5" />
            </button>
          )}
          
          {showYouTubeLink && (
            <button
              onClick={openYouTube}
              className="p-3 rounded-full backdrop-blur-sm transition-all duration-300 hover:scale-110 border"
              style={{
                backgroundColor: `rgba(0,0,0,0.7)`,
                borderColor: `${themeConfig.colors.primary}60`,
                color: themeConfig.colors.primary
              }}
              title="Ver en YouTube"
            >
              <ExternalLink className="w-5 h-5" />
            </button>
          )}
        </div>
      )}

      {/* Loading Indicator */}
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div 
            className="w-16 h-16 border-4 border-t-transparent rounded-full animate-spin"
            style={{ borderColor: `${themeConfig.colors.primary} transparent transparent transparent` }}
          ></div>
        </div>
      )}

      {/* YouTube Branding (opcional) */}
      {useEmbedded && (
        <div className="absolute top-4 right-4">
          <div 
            className="px-3 py-1 rounded-full backdrop-blur-sm border text-xs font-medium"
            style={{
              backgroundColor: `rgba(255,0,0,0.9)`,
              borderColor: `rgba(255,255,255,0.3)`,
              color: 'white'
            }}
          >
            YouTube
          </div>
        </div>
      )}

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div 
          className="w-6 h-10 border-2 rounded-full flex justify-center"
          style={{ borderColor: `${themeConfig.colors.textSecondary}60` }}
        >
          <div 
            className="w-1 h-3 rounded-full mt-2 animate-pulse"
            style={{ backgroundColor: themeConfig.colors.textSecondary }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default YouTubeVideoBanner;