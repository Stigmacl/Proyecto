# 🔧 Solución Completa para XAMPP

## 📋 Pasos para Solucionar el Error MIME

### 1. **Verificar Configuración de Apache**

Abre el archivo de configuración de Apache:
```
C:\xampp\apache\conf\httpd.conf
```

Busca y asegúrate de que estas líneas estén descomentadas (sin #):
```apache
LoadModule rewrite_module modules/mod_rewrite.so
LoadModule headers_module modules/mod_headers.so
LoadModule expires_module modules/mod_expires.so
LoadModule deflate_module modules/mod_deflate.so
```

### 2. **Configurar MIME Types en Apache**

En el mismo archivo `httpd.conf`, busca la sección `<IfModule mod_mime_module>` y agrega:
```apache
<IfModule mod_mime_module>
    # Configuración existente...
    
    # Agregar estos tipos MIME para JavaScript moderno
    AddType application/javascript .js
    AddType application/javascript .mjs
    AddType application/javascript .jsx
    AddType text/css .css
</IfModule>
```

### 3. **Reiniciar Apache**

- Abre el Panel de Control de XAMPP
- Detén Apache (botón "Stop")
- Espera 5 segundos
- Inicia Apache nuevamente (botón "Start")

### 4. **Verificar Estructura de Archivos**

Tu estructura debe ser:
```
C:\xampp\htdocs\tactical-ops\
├── index.html
├── .htaccess
└── assets/
    ├── index-[hash].js
    ├── index-[hash].css
    └── [otros archivos]
```

### 5. **Limpiar Cache del Navegador**

- Presiona `Ctrl + Shift + R` para recargar sin cache
- O abre herramientas de desarrollador (F12) → Network → "Disable cache"

## 🚀 Comandos para Regenerar el Build

Si sigues teniendo problemas, regenera el build:

```bash
# Limpiar y regenerar
npm run build

# Copiar archivos nuevamente
# Copia todo el contenido de 'dist/' a 'C:\xampp\htdocs\tactical-ops\'
```

## 🔍 Verificación de Errores

### Abrir Consola del Navegador:
1. Presiona `F12`
2. Ve a la pestaña "Network"
3. Recarga la página
4. Busca archivos .js en rojo
5. Haz clic en ellos para ver el error específico

### Verificar Headers HTTP:
En la pestaña Network, haz clic en cualquier archivo .js y verifica:
- **Content-Type**: Debe ser `application/javascript`
- **Status**: Debe ser `200 OK`

## ⚡ Solución Alternativa Rápida

Si XAMPP sigue dando problemas, usa un servidor local simple:

```bash
# Opción 1: Servidor Python (si tienes Python instalado)
cd C:\xampp\htdocs\tactical-ops
python -m http.server 8000

# Opción 2: Servidor Node.js
npm install -g serve
serve -s . -p 8000

# Luego abre: http://localhost:8000
```

## 🎯 Verificación Final

La página debe cargar correctamente en:
- `http://localhost/tactical-ops/`
- Sin errores en la consola
- Con el banner de YouTube funcionando
- Todos los estilos aplicados correctamente

## 📞 Si Persiste el Problema

1. **Verifica la versión de XAMPP**: Usa XAMPP 8.0 o superior
2. **Permisos de archivos**: Asegúrate de que XAMPP tenga permisos de lectura
3. **Firewall/Antivirus**: Temporalmente desactiva para probar
4. **Puerto ocupado**: Verifica que el puerto 80 no esté ocupado por otro servicio