# 📋 Guía Completa de Instalación - Base de Datos MySQL

## 🚀 Paso a Paso para Configurar la Base de Datos

### 1. **Preparar XAMPP**

1. **Iniciar XAMPP:**
   - Abre el Panel de Control de XAMPP
   - Inicia **Apache** y **MySQL**
   - Verifica que ambos estén en verde (Running)

2. **Verificar MySQL:**
   - Haz clic en "Admin" junto a MySQL
   - Se abrirá phpMyAdmin en tu navegador

### 2. **Crear la Base de Datos en Navicat**

1. **Abrir Navicat:**
   - Abre Navicat for MySQL
   - Crea una nueva conexión:
     - **Host:** localhost
     - **Puerto:** 3306
     - **Usuario:** root
     - **Contraseña:** (dejar vacío por defecto en XAMPP)

2. **Importar el archivo SQL:**
   - Haz clic derecho en la conexión → "Execute SQL File"
   - Selecciona el archivo `database/tactical_ops_chile.sql`
   - Ejecuta el script completo
   - Verifica que se creó la base de datos `tactical_ops_chile`

### 3. **Estructura de Archivos en XAMPP**

Copia los archivos en esta estructura:

```
C:\xampp\htdocs\tactical-ops\
├── index.html
├── assets/ (archivos del build)
├── database/
│   └── connection.php
├── api/
│   ├── auth.php
│   ├── users.php
│   ├── news.php
│   ├── comments.php
│   ├── messages.php
│   └── clans.php
└── .htaccess
```

### 4. **Configurar la Conexión**

Edita el archivo `database/connection.php` si es necesario:

```php
private $host = 'localhost';
private $db_name = 'tactical_ops_chile';
private $username = 'root';
private $password = ''; // Vacío para XAMPP por defecto
```

### 5. **Verificar Permisos**

1. **Permisos de archivos:**
   - Los archivos PHP deben tener permisos de lectura
   - La carpeta debe ser accesible por Apache

2. **Configuración de Apache:**
   - Verifica que `mod_rewrite` esté habilitado
   - El archivo `.htaccess` debe estar en la raíz

### 6. **Probar la Conexión**

1. **Crear archivo de prueba** `test_connection.php`:

```php
<?php
require_once 'database/connection.php';

try {
    $conn = getDBConnection();
    echo "✅ Conexión exitosa a la base de datos!";
    
    // Probar consulta
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM users");
    $stmt->execute();
    $result = $stmt->fetch();
    echo "<br>👥 Usuarios en la base de datos: " . $result['total'];
    
} catch(Exception $e) {
    echo "❌ Error de conexión: " . $e->getMessage();
}
?>
```

2. **Acceder a:** `http://localhost/tactical-ops/test_connection.php`

### 7. **Configurar el Frontend**

Actualiza el frontend para usar las APIs. Modifica `src/contexts/AuthContext.tsx`:

```typescript
// Cambiar las funciones para usar fetch a las APIs
const login = async (username: string, password: string): Promise<boolean> => {
  try {
    const response = await fetch('/api/auth.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'login', username, password })
    });
    
    const data = await response.json();
    if (data.success) {
      setUser(data.user);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error de login:', error);
    return false;
  }
};
```

### 8. **Datos de Prueba**

La base de datos incluye:

- **Usuario Admin:**
  - Usuario: `root`
  - Contraseña: `tacticalopschile2025`
  - Email: `admin@tacops.cl`

- **Clan Admin:** `[ADMIN]`
- **Logros básicos** predefinidos
- **Configuraciones del sistema**

### 9. **URLs de las APIs**

Las APIs estarán disponibles en:

- **Autenticación:** `http://localhost/tactical-ops/api/auth.php`
- **Usuarios:** `http://localhost/tactical-ops/api/users.php`
- **Noticias:** `http://localhost/tactical-ops/api/news.php`
- **Comentarios:** `http://localhost/tactical-ops/api/comments.php`
- **Mensajes:** `http://localhost/tactical-ops/api/messages.php`
- **Clanes:** `http://localhost/tactical-ops/api/clans.php`

### 10. **Verificación Final**

1. ✅ MySQL corriendo en XAMPP
2. ✅ Base de datos `tactical_ops_chile` creada
3. ✅ Todas las tablas importadas
4. ✅ Usuario admin creado
5. ✅ APIs funcionando
6. ✅ Frontend conectado

### 🔧 Solución de Problemas

**Error de conexión:**
- Verifica que MySQL esté corriendo
- Revisa usuario/contraseña en `connection.php`
- Asegúrate de que la base de datos existe

**Error 404 en APIs:**
- Verifica que `mod_rewrite` esté habilitado
- Revisa que el archivo `.htaccess` esté presente
- Confirma la estructura de carpetas

**Error de CORS:**
- Los headers CORS están incluidos en `connection.php`
- Verifica que no haya conflictos con otros headers

### 📊 Monitoreo

Puedes monitorear la base de datos desde:
- **Navicat:** Para gestión visual
- **phpMyAdmin:** `http://localhost/phpmyadmin`
- **Logs de Apache:** `C:\xampp\apache\logs\error.log`

¡La base de datos está lista para usar! 🎮