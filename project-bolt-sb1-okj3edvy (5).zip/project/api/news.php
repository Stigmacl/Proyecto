<?php
require_once '../database/connection.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'GET':
        getNews();
        break;
    case 'POST':
        createNews($input);
        break;
    case 'PUT':
        updateNews($input);
        break;
    case 'DELETE':
        deleteNews($input);
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
}

function getNews() {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("
            SELECT n.id, n.title, n.content, n.image, n.is_pinned, n.views, n.likes, n.created_at as date,
                   u.username as author,
                   (SELECT COUNT(*) FROM comments c WHERE c.news_id = n.id AND c.is_deleted = 0) as comment_count
            FROM news n 
            JOIN users u ON n.author_id = u.id 
            ORDER BY n.is_pinned DESC, n.created_at DESC
        ");
        $stmt->execute();
        $news = $stmt->fetchAll();
        
        // Obtener comentarios y likes para cada noticia
        foreach($news as &$item) {
            // Comentarios
            $commentsStmt = $conn->prepare("
                SELECT c.id, c.content, c.created_at as date, c.is_deleted, c.deletion_reason,
                       u.username as author, u.avatar
                FROM comments c 
                JOIN users u ON c.user_id = u.id 
                WHERE c.news_id = ? 
                ORDER BY c.created_at ASC
            ");
            $commentsStmt->execute([$item['id']]);
            $item['comments'] = $commentsStmt->fetchAll();
            
            // Likes
            $likesStmt = $conn->prepare("SELECT user_id FROM news_likes WHERE news_id = ?");
            $likesStmt->execute([$item['id']]);
            $likes = $likesStmt->fetchAll();
            $item['likedBy'] = array_column($likes, 'user_id');
            
            $item['isPinned'] = (bool)$item['is_pinned'];
        }
        
        echo json_encode(['success' => true, 'news' => $news]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function createNews($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("INSERT INTO news (title, content, image, author_id, is_pinned, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $data['title'],
            $data['content'],
            $data['image'],
            $data['authorId'],
            $data['isPinned'] ? 1 : 0
        ]);
        
        echo json_encode(['success' => true, 'id' => $conn->lastInsertId()]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function updateNews($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("UPDATE news SET title = ?, content = ?, image = ?, is_pinned = ? WHERE id = ?");
        $stmt->execute([
            $data['title'],
            $data['content'],
            $data['image'],
            $data['isPinned'] ? 1 : 0,
            $data['id']
        ]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function deleteNews($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("DELETE FROM news WHERE id = ?");
        $stmt->execute([$data['id']]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}
?>