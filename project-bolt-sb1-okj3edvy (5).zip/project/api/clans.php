<?php
require_once '../database/connection.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'GET':
        getClans();
        break;
    case 'POST':
        createClan($input);
        break;
    case 'PUT':
        updateClan($input);
        break;
    case 'DELETE':
        deleteClan($input);
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
}

function getClans() {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("
            SELECT c.*, u.username as creator_name,
                   (SELECT COUNT(*) FROM users WHERE clan_id = c.id) as member_count
            FROM clans c 
            JOIN users u ON c.created_by = u.id 
            ORDER BY c.created_at DESC
        ");
        $stmt->execute();
        $clans = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'clans' => $clans]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function createClan($data) {
    $conn = getDBConnection();
    
    try {
        // Verificar que el tag no exista
        $checkStmt = $conn->prepare("SELECT id FROM clans WHERE tag = ?");
        $checkStmt->execute([$data['tag']]);
        
        if ($checkStmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'El tag del clan ya existe']);
            return;
        }
        
        $stmt = $conn->prepare("INSERT INTO clans (name, tag, logo, description, created_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $data['name'],
            $data['tag'],
            $data['logo'],
            $data['description'],
            $data['createdBy']
        ]);
        
        echo json_encode(['success' => true, 'id' => $conn->lastInsertId()]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function updateClan($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("UPDATE clans SET name = ?, tag = ?, logo = ?, description = ? WHERE id = ?");
        $stmt->execute([
            $data['name'],
            $data['tag'],
            $data['logo'],
            $data['description'],
            $data['id']
        ]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function deleteClan($data) {
    $conn = getDBConnection();
    
    try {
        // Remover clan de todos los usuarios
        $updateUsersStmt = $conn->prepare("UPDATE users SET clan_id = NULL WHERE clan_id = ?");
        $updateUsersStmt->execute([$data['id']]);
        
        // Eliminar clan
        $stmt = $conn->prepare("DELETE FROM clans WHERE id = ?");
        $stmt->execute([$data['id']]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}
?>