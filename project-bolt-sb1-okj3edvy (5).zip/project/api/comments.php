<?php
require_once '../database/connection.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'POST':
        if (isset($input['action'])) {
            switch($input['action']) {
                case 'add':
                    addComment($input);
                    break;
                case 'like':
                    likeNews($input);
                    break;
                case 'view':
                    incrementViews($input);
                    break;
            }
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
}

function addComment($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("INSERT INTO comments (news_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([
            $data['newsId'],
            $data['userId'],
            $data['content']
        ]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function likeNews($data) {
    $conn = getDBConnection();
    
    try {
        // Verificar si ya le dio like
        $checkStmt = $conn->prepare("SELECT id FROM news_likes WHERE news_id = ? AND user_id = ?");
        $checkStmt->execute([$data['newsId'], $data['userId']]);
        
        if ($checkStmt->fetch()) {
            // Quitar like
            $deleteStmt = $conn->prepare("DELETE FROM news_likes WHERE news_id = ? AND user_id = ?");
            $deleteStmt->execute([$data['newsId'], $data['userId']]);
            
            $updateStmt = $conn->prepare("UPDATE news SET likes = likes - 1 WHERE id = ?");
            $updateStmt->execute([$data['newsId']]);
        } else {
            // Agregar like
            $insertStmt = $conn->prepare("INSERT INTO news_likes (news_id, user_id) VALUES (?, ?)");
            $insertStmt->execute([$data['newsId'], $data['userId']]);
            
            $updateStmt = $conn->prepare("UPDATE news SET likes = likes + 1 WHERE id = ?");
            $updateStmt->execute([$data['newsId']]);
        }
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function incrementViews($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("UPDATE news SET views = views + 1 WHERE id = ?");
        $stmt->execute([$data['newsId']]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}
?>