<?php
require_once '../database/connection.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'GET':
        getUsers();
        break;
    case 'PUT':
        updateUser($input);
        break;
    case 'DELETE':
        deleteUser($input);
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
}

function getUsers() {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("
            SELECT u.id, u.username, u.email, u.role, u.avatar, u.status, 
                   u.is_online, u.is_active, u.last_login, u.created_at,
                   c.tag as clan
            FROM users u 
            LEFT JOIN clans c ON u.clan_id = c.id 
            ORDER BY u.created_at DESC
        ");
        $stmt->execute();
        $users = $stmt->fetchAll();
        
        // Formatear datos para el frontend
        foreach($users as &$user) {
            $user['isOnline'] = (bool)$user['is_online'];
            $user['isActive'] = (bool)$user['is_active'];
        }
        
        echo json_encode(['success' => true, 'users' => $users]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function updateUser($data) {
    $conn = getDBConnection();
    
    try {
        $updates = [];
        $params = [];
        
        if (isset($data['username'])) {
            $updates[] = "username = ?";
            $params[] = $data['username'];
        }
        if (isset($data['email'])) {
            $updates[] = "email = ?";
            $params[] = $data['email'];
        }
        if (isset($data['role'])) {
            $updates[] = "role = ?";
            $params[] = $data['role'];
        }
        if (isset($data['avatar'])) {
            $updates[] = "avatar = ?";
            $params[] = $data['avatar'];
        }
        if (isset($data['status'])) {
            $updates[] = "status = ?";
            $params[] = $data['status'];
        }
        if (isset($data['clan'])) {
            // Buscar ID del clan por tag
            $clanStmt = $conn->prepare("SELECT id FROM clans WHERE tag = ?");
            $clanStmt->execute([$data['clan']]);
            $clan = $clanStmt->fetch();
            
            $updates[] = "clan_id = ?";
            $params[] = $clan ? $clan['id'] : null;
        }
        
        $params[] = $data['userId'];
        
        $sql = "UPDATE users SET " . implode(", ", $updates) . " WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function deleteUser($data) {
    $conn = getDBConnection();
    
    try {
        // No permitir eliminar al usuario root
        if ($data['userId'] == 1) {
            echo json_encode(['success' => false, 'error' => 'No se puede eliminar al administrador principal']);
            return;
        }
        
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$data['userId']]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}
?>