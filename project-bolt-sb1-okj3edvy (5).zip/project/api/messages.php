<?php
require_once '../database/connection.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'GET':
        if (isset($_GET['conversation'])) {
            getConversation($_GET['user1'], $_GET['user2']);
        } else {
            getMessages($_GET['userId']);
        }
        break;
    case 'POST':
        sendMessage($input);
        break;
    case 'PUT':
        markAsRead($input);
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
}

function getMessages($userId) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("
            SELECT m.*, u1.username as from_username, u2.username as to_username
            FROM messages m
            JOIN users u1 ON m.from_user_id = u1.id
            JOIN users u2 ON m.to_user_id = u2.id
            WHERE m.from_user_id = ? OR m.to_user_id = ?
            ORDER BY m.created_at DESC
        ");
        $stmt->execute([$userId, $userId]);
        $messages = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'messages' => $messages]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function getConversation($user1, $user2) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("
            SELECT m.*, u.username as from_username, u.avatar as from_avatar
            FROM messages m
            JOIN users u ON m.from_user_id = u.id
            WHERE (m.from_user_id = ? AND m.to_user_id = ?) 
               OR (m.from_user_id = ? AND m.to_user_id = ?)
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([$user1, $user2, $user2, $user1]);
        $messages = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'messages' => $messages]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function sendMessage($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("INSERT INTO messages (from_user_id, to_user_id, content, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([
            $data['fromUserId'],
            $data['toUserId'],
            $data['content']
        ]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function markAsRead($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
        $stmt->execute([$data['messageId']]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}
?>