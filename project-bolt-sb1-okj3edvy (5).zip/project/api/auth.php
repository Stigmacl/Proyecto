<?php
require_once '../database/connection.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'POST':
        if (isset($input['action'])) {
            switch($input['action']) {
                case 'login':
                    login($input);
                    break;
                case 'register':
                    register($input);
                    break;
                case 'logout':
                    logout($input);
                    break;
                default:
                    http_response_code(400);
                    echo json_encode(['error' => 'Acción no válida']);
            }
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
}

function login($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("SELECT id, username, email, password_hash, role, avatar, status, clan_id FROM users WHERE username = ? AND is_active = 1");
        $stmt->execute([$data['username']]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($data['password'], $user['password_hash'])) {
            // Actualizar último login y estado online
            $updateStmt = $conn->prepare("UPDATE users SET last_login = NOW(), is_online = 1 WHERE id = ?");
            $updateStmt->execute([$user['id']]);
            
            // Obtener información del clan si tiene
            $clanInfo = null;
            if ($user['clan_id']) {
                $clanStmt = $conn->prepare("SELECT tag FROM clans WHERE id = ?");
                $clanStmt->execute([$user['clan_id']]);
                $clan = $clanStmt->fetch();
                $clanInfo = $clan ? $clan['tag'] : null;
            }
            
            unset($user['password_hash']);
            $user['clan'] = $clanInfo;
            $user['isOnline'] = true;
            $user['isActive'] = true;
            
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Credenciales incorrectas']);
        }
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function register($data) {
    $conn = getDBConnection();
    
    try {
        // Verificar si el usuario o email ya existe
        $checkStmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $checkStmt->execute([$data['username'], $data['email']]);
        
        if ($checkStmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Usuario o email ya existe']);
            return;
        }
        
        // Crear nuevo usuario
        $passwordHash = password_hash($data['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, avatar, status, is_online, created_at) VALUES (?, ?, ?, ?, ?, 1, NOW())");
        $stmt->execute([
            $data['username'],
            $data['email'],
            $passwordHash,
            'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
            'Nuevo jugador'
        ]);
        
        $userId = $conn->lastInsertId();
        
        // Crear estadísticas iniciales
        $statsStmt = $conn->prepare("INSERT INTO player_stats (user_id) VALUES (?)");
        $statsStmt->execute([$userId]);
        
        // Asignar logro de primera conexión
        $achievementStmt = $conn->prepare("INSERT INTO user_achievements (user_id, achievement_id) VALUES (?, 1)");
        $achievementStmt->execute([$userId]);
        
        // Obtener datos del usuario creado
        $userStmt = $conn->prepare("SELECT id, username, email, role, avatar, status FROM users WHERE id = ?");
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        
        $user['clan'] = null;
        $user['isOnline'] = true;
        $user['isActive'] = true;
        
        echo json_encode(['success' => true, 'user' => $user]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}

function logout($data) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("UPDATE users SET is_online = 0 WHERE id = ?");
        $stmt->execute([$data['userId']]);
        
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
    }
}
?>