# 🎯 Guía Completa: XAMPP + Base de Datos

## 📂 **PASO 1: Estructura Exacta de Archivos**

### **Copiar archivos en este orden:**

```
C:\xampp\htdocs\tactical-ops\
├── index.html          ← Copiar de dist/
├── .htaccess           ← Copiar de dist/
├── assets/             ← Copiar toda la carpeta de dist/
│   ├── index-CbWLPOfY.js
│   ├── index-DrdzE5Fz.css
│   └── [otros archivos]
├── database/           ← Copiar del proyecto original
│   └── connection.php
├── api/                ← Copiar del proyecto original
│   ├── auth.php
│   ├── users.php
│   ├── news.php
│   ├── comments.php
│   ├── messages.php
│   └── clans.php
└── test_connection.php ← Copiar del proyecto original
```

### **Comandos específicos:**

1. **Copiar build:**
   ```
   Origen: [tu-proyecto]/dist/*
   Destino: C:\xampp\htdocs\tactical-ops\
   ```

2. **Copiar archivos de base de datos:**
   ```
   Origen: [tu-proyecto]/database/
   Destino: C:\xampp\htdocs\tactical-ops\database\
   
   Origen: [tu-proyecto]/api/
   Destino: C:\xampp\htdocs\tactical-ops\api\
   
   Origen: [tu-proyecto]/test_connection.php
   Destino: C:\xampp\htdocs\tactical-ops\test_connection.php
   ```

## 🔍 **PASO 2: Verificar Conexión a Base de Datos**

### **1. Probar conexión directa:**
```
http://localhost/tactical-ops/test_connection.php
```

**Debes ver:**
- ✅ Conexión exitosa a la base de datos MySQL!
- 👥 Usuarios registrados: 1
- 🛡️ Clanes creados: 1
- 📰 Noticias publicadas: 0
- 🏆 Logros disponibles: 5

### **2. Verificar en la aplicación web:**
```
http://localhost/tactical-ops/
```

**Hacer login con:**
- Usuario: `root`
- Contraseña: `tacticalopschile2025`

### **3. Crear una noticia de prueba:**
1. Hacer login como admin
2. Ir a "Admin" → "Gestión de Noticias"
3. Crear una noticia nueva
4. **Recargar la página** → La noticia debe seguir ahí

### **4. Crear un usuario de prueba:**
1. Ir a "Mi Perfil" → "Registrarse"
2. Crear un usuario nuevo
3. **Recargar la página** → El usuario debe seguir existente

## 🔧 **PASO 3: Verificar APIs Funcionando**

### **Probar APIs manualmente:**

1. **API de usuarios:**
   ```
   http://localhost/tactical-ops/api/users.php
   ```

2. **API de noticias:**
   ```
   http://localhost/tactical-ops/api/news.php
   ```

**Debes ver respuestas JSON, no errores 404**

## 🚨 **PASO 4: Señales de que la BD está Conectada**

### **✅ Señales POSITIVAS:**
- El archivo `test_connection.php` muestra "Conexión exitosa"
- Puedes hacer login con el usuario `root`
- Las noticias que creas se mantienen al recargar
- Los usuarios nuevos aparecen en la lista
- No hay errores de "fetch failed" en la consola

### **❌ Señales de PROBLEMAS:**
- `test_connection.php` muestra errores
- No puedes hacer login
- Los datos desaparecen al recargar
- Errores 404 en las APIs
- Errores de CORS en la consola

## 🔍 **PASO 5: Diagnóstico Avanzado**

### **Verificar en DevTools (F12):**

1. **Consola (Console):**
   - No debe haber errores rojos
   - Buscar mensajes como "fetch failed"

2. **Network:**
   - Las llamadas a `/api/` deben devolver 200 OK
   - No debe haber errores 404 o 500

3. **Application → Local Storage:**
   - Debe estar vacío (ya no usamos localStorage)

### **Verificar en Navicat:**

1. **Abrir la base de datos `tactical_ops_chile`**
2. **Revisar tabla `users`:**
   - Debe tener al menos 1 usuario (root)
3. **Revisar tabla `news`:**
   - Debe mostrar las noticias que crees
4. **Revisar tabla `clans`:**
   - Debe tener el clan ADMIN

## 🎯 **PASO 6: Prueba Definitiva**

### **Test completo de funcionalidad:**

1. **Crear noticia:**
   - Login como admin
   - Crear noticia con imagen
   - Recargar página → Debe seguir ahí

2. **Registrar usuario:**
   - Registrar nuevo usuario
   - Logout y login con el nuevo usuario
   - Debe funcionar

3. **Enviar mensaje:**
   - Ir a "Jugadores"
   - Enviar mensaje a otro usuario
   - Verificar en "Mi Perfil" → "Mensajes"

4. **Dar like a noticia:**
   - Dar like a una noticia
   - Recargar → El like debe mantenerse

## 📊 **PASO 7: Monitoreo Continuo**

### **Para verificar que todo funciona:**

1. **Revisar logs de Apache:**
   ```
   C:\xampp\apache\logs\error.log
   ```

2. **Revisar logs de MySQL:**
   ```
   C:\xampp\mysql\data\[nombre-pc].err
   ```

3. **Verificar en phpMyAdmin:**
   ```
   http://localhost/phpmyadmin
   ```

## 🚀 **Resultado Final Esperado**

Cuando todo esté funcionando correctamente:

- ✅ `http://localhost/tactical-ops/` carga la web
- ✅ `http://localhost/tactical-ops/test_connection.php` muestra conexión exitosa
- ✅ Login funciona con `root` / `tacticalopschile2025`
- ✅ Los datos se guardan permanentemente
- ✅ No hay errores en la consola del navegador
- ✅ Las APIs responden correctamente

## 🆘 **Si Algo No Funciona**

1. **Verificar que MySQL esté corriendo** en XAMPP
2. **Verificar que Apache esté corriendo** en XAMPP
3. **Revisar que los archivos estén en las carpetas correctas**
4. **Verificar permisos de las carpetas**
5. **Limpiar cache del navegador** (Ctrl+Shift+R)

¡Con esto deberías tener todo funcionando perfectamente! 🎮